﻿namespace WindowsFormsPerson
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Feedback = new System.Windows.Forms.Label();
            this.PerFeedback = new System.Windows.Forms.Label();
            this.Button = new System.Windows.Forms.Button();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.txtMName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtStreet1 = new System.Windows.Forms.TextBox();
            this.txtStreet2 = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCellPhone = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtInstagramUrl = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dtnDateSince = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTotalPurchases = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtRewardsEarned = new System.Windows.Forms.TextBox();
            this.boolDiscountMember = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Middle Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Street 1:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Street 2:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "City:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 173);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "State:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Zip:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 237);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Phone:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 266);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Email:";
            // 
            // Feedback
            // 
            this.Feedback.AutoSize = true;
            this.Feedback.Location = new System.Drawing.Point(3, 371);
            this.Feedback.Name = "Feedback";
            this.Feedback.Size = new System.Drawing.Size(0, 16);
            this.Feedback.TabIndex = 10;
            // 
            // PerFeedback
            // 
            this.PerFeedback.Location = new System.Drawing.Point(3, 356);
            this.PerFeedback.Name = "PerFeedback";
            this.PerFeedback.Size = new System.Drawing.Size(793, 85);
            this.PerFeedback.TabIndex = 11;
            this.PerFeedback.Text = "Feedback Goes Here";
            // 
            // Button
            // 
            this.Button.Location = new System.Drawing.Point(287, 330);
            this.Button.Name = "Button";
            this.Button.Size = new System.Drawing.Size(131, 23);
            this.Button.TabIndex = 12;
            this.Button.Text = "Add Person ";
            this.Button.UseVisualStyleBackColor = true;
            this.Button.Click += new System.EventHandler(this.Button_Click);
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(89, 6);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(114, 22);
            this.txtFName.TabIndex = 13;
            // 
            // txtMName
            // 
            this.txtMName.Location = new System.Drawing.Point(107, 38);
            this.txtMName.Name = "txtMName";
            this.txtMName.Size = new System.Drawing.Size(138, 22);
            this.txtMName.TabIndex = 14;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(93, 66);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(163, 22);
            this.txtLName.TabIndex = 15;
            // 
            // txtStreet1
            // 
            this.txtStreet1.Location = new System.Drawing.Point(71, 93);
            this.txtStreet1.Name = "txtStreet1";
            this.txtStreet1.Size = new System.Drawing.Size(165, 22);
            this.txtStreet1.TabIndex = 16;
            // 
            // txtStreet2
            // 
            this.txtStreet2.Location = new System.Drawing.Point(67, 124);
            this.txtStreet2.Name = "txtStreet2";
            this.txtStreet2.Size = new System.Drawing.Size(169, 22);
            this.txtStreet2.TabIndex = 17;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(46, 148);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(122, 22);
            this.txtCity.TabIndex = 18;
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(53, 173);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(50, 22);
            this.txtState.TabIndex = 19;
            // 
            // txtZip
            // 
            this.txtZip.Location = new System.Drawing.Point(44, 203);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(77, 22);
            this.txtZip.TabIndex = 20;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(59, 234);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(144, 22);
            this.txtPhone.TabIndex = 21;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(59, 263);
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(206, 23);
            this.txtEmail.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 302);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 16);
            this.label11.TabIndex = 23;
            this.label11.Text = "Cell Phone:";
            // 
            // txtCellPhone
            // 
            this.txtCellPhone.Location = new System.Drawing.Point(89, 299);
            this.txtCellPhone.Name = "txtCellPhone";
            this.txtCellPhone.Size = new System.Drawing.Size(147, 22);
            this.txtCellPhone.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(264, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 16);
            this.label12.TabIndex = 25;
            this.label12.Text = "Instagram URL:";
            // 
            // txtInstagramUrl
            // 
            this.txtInstagramUrl.Location = new System.Drawing.Point(369, 3);
            this.txtInstagramUrl.Name = "txtInstagramUrl";
            this.txtInstagramUrl.Size = new System.Drawing.Size(210, 22);
            this.txtInstagramUrl.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(264, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 16);
            this.label13.TabIndex = 27;
            this.label13.Text = "Customer Since:";
            // 
            // dtnDateSince
            // 
            this.dtnDateSince.Location = new System.Drawing.Point(369, 35);
            this.dtnDateSince.Name = "dtnDateSince";
            this.dtnDateSince.Size = new System.Drawing.Size(200, 22);
            this.dtnDateSince.TabIndex = 28;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(264, 66);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 16);
            this.label14.TabIndex = 29;
            this.label14.Text = "Total Purchases:";
            // 
            // txtTotalPurchases
            // 
            this.txtTotalPurchases.Location = new System.Drawing.Point(369, 63);
            this.txtTotalPurchases.Name = "txtTotalPurchases";
            this.txtTotalPurchases.Size = new System.Drawing.Size(49, 22);
            this.txtTotalPurchases.TabIndex = 30;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(264, 96);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 16);
            this.label15.TabIndex = 31;
            this.label15.Text = "Discount Member:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(264, 124);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(108, 16);
            this.label16.TabIndex = 33;
            this.label16.Text = "RewardsEarned:";
            // 
            // txtRewardsEarned
            // 
            this.txtRewardsEarned.Location = new System.Drawing.Point(378, 121);
            this.txtRewardsEarned.Name = "txtRewardsEarned";
            this.txtRewardsEarned.Size = new System.Drawing.Size(50, 22);
            this.txtRewardsEarned.TabIndex = 34;
            // 
            // boolDiscountMember
            // 
            this.boolDiscountMember.AutoSize = true;
            this.boolDiscountMember.Location = new System.Drawing.Point(378, 95);
            this.boolDiscountMember.Name = "boolDiscountMember";
            this.boolDiscountMember.Size = new System.Drawing.Size(95, 20);
            this.boolDiscountMember.TabIndex = 35;
            this.boolDiscountMember.TabStop = false;
            this.boolDiscountMember.Text = "checkBox1";
            this.boolDiscountMember.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.boolDiscountMember);
            this.Controls.Add(this.txtRewardsEarned);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtTotalPurchases);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dtnDateSince);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtInstagramUrl);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtCellPhone);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtStreet2);
            this.Controls.Add(this.txtStreet1);
            this.Controls.Add(this.txtLName);
            this.Controls.Add(this.txtMName);
            this.Controls.Add(this.txtFName);
            this.Controls.Add(this.Button);
            this.Controls.Add(this.PerFeedback);
            this.Controls.Add(this.Feedback);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label Feedback;
        private System.Windows.Forms.Label PerFeedback;
        private System.Windows.Forms.Button Button;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.TextBox txtMName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtStreet1;
        private System.Windows.Forms.TextBox txtStreet2;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCellPhone;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtInstagramUrl;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtnDateSince;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTotalPurchases;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtRewardsEarned;
        private System.Windows.Forms.CheckBox boolDiscountMember;
    }
}

